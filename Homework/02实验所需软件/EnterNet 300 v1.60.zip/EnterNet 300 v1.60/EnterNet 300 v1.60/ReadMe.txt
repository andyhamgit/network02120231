                      Efficient Networks, Inc.
   EnterNet 300 v1.5 for Windows 9x,Windows NT4 and Windows 2000

                   (Beta - OEM, Eval and Retail)

                              "ReadMe"

This file supplements the information in the EnterNet 300 Help 
system. It contains EnterNet 300 installation guidelines, infor-
mation about getting support for EnterNet 300, and information 
about features or issues that are not yet documented elsewhere.

This ReadMe file consists of the following sections:

1. Installing EnterNet 300 for Windows
2. Technical Support
3. Documentation Addenda


1. Installing EnterNet 300 for Windows
======================================

Overview
--------
If you received EnterNet 300 as a component of a suite of applica-
tions, follow the installation instructions provided therein. If you 
are installing EnterNet 300 as a stand-alone application, follow the 
instructions below.

EnterNet 300 is distributed in three formats: 
(i) On CD-ROM. 
(ii) As a self-extracting executable (typically ENTERNET300.EXE).
(iii) As a "zip" archive (typically ENTERNET300.ZIP). Please refer
to the appropriate paragraph below, based on your distribution
format. 

Installing from a CD
--------------------
If you are installing EnterNet 300 from a CD, insert the EnterNet 300
CD into your CD-ROM drive. If after 30 seconds the EnterNet 300 
installer has not automatically started, use Windows Explorer to 
navigate to the root directory of the EnterNet 300 CD, and double-
click the file named SETUP.EXE. Follow the on-screen  instructions. 
See "Installation Options" below, for additional information.

Installing from a Self-Extracting Executable
--------------------------------------------
If you received EnterNet 300 electronically, and the file you 
received has an "EXE" extension (like ENTERNET300.EXE), simply 
double-click on the file and follow the on-screen instructions. See 
"Installation Options" below, for additional information.

Installing from a "zip" Archive
------------------------------
If you are installing EnterNet 300 from a "zip" archive file (like 
ENTERNET300.ZIP), create a temporary folder on your computer's hard 
drive and extract all the files from the EnterNet 300 zip archive to 
the temporary folder. Use Windows Explorer to navigate to the temp-
orary folder, then double-click the file named SETUP.EXE. Follow the 
on-screen instructions. After you have successfully installed 
EnterNet 300, you may delete the temporary folder and its contents. 
See "Installation Options" below, for additional information.

Installing on Windows NT & Windows 2000 Systems
-----------------------------------------------
If you are installing EnterNet 300 on a Windows NT or Windows 2000 
computer, you must install it while logged onto a Windows user 
account that possesses Administrator privileges. EnterNet 300 is 
installed as a Service, and is available to user accounts that do 
not have Administrator privileges.

Installation Options
--------------------
When you launch the EnterNet 300 installer, you will be asked to 
select between a "Quick Install" and a "Step-By-Step" install. If you 
select Quick Install, then EnterNet 300's default installation values
are selected. You are then prompted whether to re-boot your system.
If you select Step-By-Step Install, you are prompted:
1. To install the EnterNet 300 icon on your desktop (the 
default value is "Yes"). 
2. To activate EnterNet 300's Dial-on-Demand feature (the
default value is "No"). 
3. To accept the default installation folder, or select another hard
drive folder where EnterNet is to be installed.


2. Technical Support
====================
Should you find yourself in need of assistance with EnterNet 300 you
should check the EnterNet 300 Help system,  the User's Guide, and 
the online "Frequently Asked Questions" (FAQ) file before calling
your technical support representative. To view the FAQ, point your
browser to: http://support.efficient.com/KB/NTS/index.html
 
You can launch the Help system either from within the EnterNet 300 
application or by selecting Help from the EnterNet 300 folder on
the Windows Start menu. You can launch the User's Guide by 
double-clicking the file named USERSGUIDE.PDF in the \app 
subdirectory where EnterNet 300 was installed. You must have Adobe 
Acrobat Reader installed on your computer in order to view the User's
Guide. You can download this free product from the Adobe WWW page at 
the following URL: http://www.adobe.com. 

If you still need assistance after reading the FAQ, you should 
contact your technical support representative. 
NOTE: Efficient Networks, the OEM manufacturer of EnterNet 300, does
not provide technical assistance directly to end users.


3. Documentation Addenda
========================
There are no undocumented features in this release.

07-DEC-00 8:12AM  RF